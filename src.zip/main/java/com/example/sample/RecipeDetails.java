package com.example.sample;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.drawable.BitmapDrawable;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class RecipeDetails extends AppCompatActivity {
    TextView heading, timeTV, inNAmtTV, stepsTV, linkTV;
    ImageView imageView;
    DatabaseReference reference;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recipe_details);
        heading = (TextView) findViewById(R.id.title);
        imageView = (ImageView) findViewById(R.id.img);

//        Bitmap mbitmap = ((BitmapDrawable) getResources().getDrawable(R.drawable.img)).getBitmap();
//        Bitmap imageRounded=Bitmap.createBitmap(mbitmap.getWidth(), mbitmap.getHeight(), mbitmap.getConfig());
//        Canvas canvas=new Canvas(imageRounded);
//        Paint mpaint=new Paint();
//        mpaint.setAntiAlias(true);
//        mpaint.setShader(new BitmapShader(mbitmap, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP));
//        canvas.drawRoundRect((new RectF(0, 0, mbitmap.getWidth(), mbitmap.getHeight())), 100, 100, mpaint); // Round Image Corner 100 100 100 100
//        imageView.setImageBitmap(imageRounded);

        timeTV = (TextView) findViewById(R.id.time);
        inNAmtTV = (TextView) findViewById(R.id.inNAmt);
        stepsTV = (TextView) findViewById(R.id.r_steps);
        linkTV = (TextView) findViewById(R.id.vLink);
        Intent intent = getIntent();
        String name = intent.getStringExtra("name");
        heading.setText(name);

        reference = FirebaseDatabase.getInstance().getReference("Recipes");

        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                for(DataSnapshot ds: snapshot.getChildren()) {
                    RecipeData data = ds.getValue(RecipeData.class);
                    if (name.equals(data.rName)) {


                        String time = data.time;
                        String igNAmt = data.igNAmt;
                        String steps = data.steps;
                        String link = data.link;

                        Picasso.get().load(data.imageUrl).placeholder(R.drawable.bck).into(imageView);
                        timeTV.setText(time + " minutes");
                        inNAmtTV.setText("\n" + igNAmt);
                        stepsTV.setText("\n" + steps);
                        linkTV.setText(link);



                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(RecipeDetails.this, "Something went wrong!!", Toast.LENGTH_LONG).show();
            }
        });
    }
}