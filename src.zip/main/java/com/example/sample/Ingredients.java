package com.example.sample;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ListView;
import java.util.ArrayList;
import java.util.Locale;

public class Ingredients extends AppCompatActivity {

    androidx.appcompat.widget.SearchView searchView;
    ListView listView;
    listview_arrayAdapter arrayAdapter;
    CheckBox checkBox;
    Button submit;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ingredients);

        ArrayList<CustomAdapter> arrayList = setArrayListItems();

        arrayAdapter = new listview_arrayAdapter(Ingredients.this, R.layout.items, arrayList);
        listView = (ListView) findViewById(R.id.listView);
        listView.setAdapter(arrayAdapter);

        checkBox = (CheckBox) findViewById(R.id.item);

        submit = (Button) findViewById(R.id.submit);

        searchView = (androidx.appcompat.widget.SearchView) findViewById(R.id.searchView);


        searchView.setOnQueryTextListener(new androidx.appcompat.widget.SearchView.OnQueryTextListener() {

            @Override
            public boolean onQueryTextSubmit(String query) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                ArrayList<CustomAdapter> results = new ArrayList<>();
                ArrayList<CustomAdapter> temp = setArrayListItems();

                if(newText.isEmpty()) {
                    results = temp;
                } else {
                    for(CustomAdapter x : temp) {
                        if(x.getItem_name().toLowerCase().startsWith(newText.toLowerCase())) {
                            results.add(x);
                        }
                    }
                }

                arrayList.clear();
                arrayList.addAll(results);
                arrayAdapter.notifyDataSetChanged();

                return true;
            }
        });


        submit.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                ArrayList<String> checklist = listview_arrayAdapter.show();
                MoveToResultantRecipes(checklist);
            }
        });


    }

    public ArrayList setArrayListItems() {

        ArrayList<CustomAdapter> arrayList = new ArrayList<>();

        arrayList.add(new CustomAdapter("Potato"));
        arrayList.add(new CustomAdapter("Tomato"));
        arrayList.add(new CustomAdapter("Peas"));
        arrayList.add(new CustomAdapter("Cabbage"));
        arrayList.add(new CustomAdapter("Cauliflower"));
        arrayList.add(new CustomAdapter("Bitter gourd"));
        arrayList.add(new CustomAdapter("Gourd"));
        arrayList.add(new CustomAdapter("Ladyfinger"));
        arrayList.add(new CustomAdapter("Onion"));
        arrayList.add(new CustomAdapter("Spinach"));
        arrayList.add(new CustomAdapter("Sprouts"));
        arrayList.add(new CustomAdapter("Eggplant"));
        arrayList.add(new CustomAdapter("Carrot"));
        arrayList.add(new CustomAdapter("Radish"));
        arrayList.add(new CustomAdapter("Chicken Wings"));
        arrayList.add(new CustomAdapter("Chickpeas"));
        arrayList.add(new CustomAdapter("Flour"));
        arrayList.add(new CustomAdapter("Corn Flour"));
        arrayList.add(new CustomAdapter("Egg"));
        arrayList.add(new CustomAdapter("Yogurt"));
        arrayList.add(new CustomAdapter("Corn Tortillas"));
        arrayList.add(new CustomAdapter("Margarine"));
        arrayList.add(new CustomAdapter("Creole Seasoning"));
        arrayList.add(new CustomAdapter("Milk"));
        arrayList.add(new CustomAdapter("Butter"));
        arrayList.add(new CustomAdapter("Basmati Rice"));
        arrayList.add(new CustomAdapter("Boneless Chicken"));
        arrayList.add(new CustomAdapter("Mint"));
        arrayList.add(new CustomAdapter("Chicken Stock"));
        arrayList.add(new CustomAdapter("Chicken"));
        arrayList.add(new CustomAdapter("Flat Breads"));
        arrayList.add(new CustomAdapter("Hot Sauce"));
        arrayList.add(new CustomAdapter("Cheese"));
        arrayList.add(new CustomAdapter("Kidney Beans"));
        arrayList.add(new CustomAdapter("Rice"));
        arrayList.add(new CustomAdapter("Chicken Breast"));
        arrayList.add(new CustomAdapter("Cream"));
        arrayList.add(new CustomAdapter("Macaroni"));
        arrayList.add(new CustomAdapter("Gram Flour"));
        arrayList.add(new CustomAdapter("Capsicum"));
        arrayList.add(new CustomAdapter("Chicken Leg"));
        arrayList.add(new CustomAdapter("Charcoal"));
        arrayList.add(new CustomAdapter("Apple"));
        arrayList.add(new CustomAdapter("Nectarines"));
        arrayList.add(new CustomAdapter("Stalks Celery"));
        arrayList.add(new CustomAdapter("Walnuts"));
        arrayList.add(new CustomAdapter("Cranberries"));



        return arrayList;

    }

    public void MoveToResultantRecipes(ArrayList<String> list) {
        ArrayList<String> finalList = new ArrayList<>();
        for (String i : list) {
            finalList.add(i.toLowerCase(Locale.ROOT).replaceAll(" ", ""));
        }
        Intent intent = new Intent(Ingredients.this, ResultantRecipes.class);
        intent.putExtra("the list", finalList);
        startActivity(intent);
    }
}