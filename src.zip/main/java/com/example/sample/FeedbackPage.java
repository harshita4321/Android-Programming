package com.example.sample;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.Rating;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;

import java.io.InputStream;
import java.net.URL;

public class FeedbackPage extends AppCompatActivity {
    TextView title;
    ImageView image;
    RatingBar rb;
    EditText writtenFB;
    Button submit;
    Bitmap myBitmap;
    float rate;
    float totalStars;
    String recipeName;
    String email;
    String textFeedback;
    DatabaseReference databaseReference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_feedback_page);

        title = (TextView) findViewById(R.id.fTitle);
        image = (ImageView) findViewById(R.id.fImg);
        rb = (RatingBar) findViewById(R.id.frb);
        writtenFB = (EditText) findViewById(R.id.fEdit);
        submit = (Button) findViewById(R.id.save);

        title.setGravity(1);
        title.setTextSize(22);
        title.setSingleLine(true);

        databaseReference = FirebaseDatabase.getInstance().getReference("Recipes");
        SessionManagement sessionManagement = new SessionManagement(FeedbackPage.this);
        email = sessionManagement.getSession();
        Bundle msg = getIntent().getExtras();
        recipeName = msg.getString("id");
        title.setText(recipeName);
        totalStars=rb.getNumStars();

        databaseReference.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                for(DataSnapshot ds : snapshot.getChildren()) {
                    //Images im = ds.getValue(Images.class);
                    if(ds.child("rName").getValue().toString().equals(recipeName)) {
                        //Toast.makeText(FeedbackPage.this, ds.child("imageUrl").getValue().toString(), Toast.LENGTH_SHORT).show();
                        //Picasso.get().load(ds.child("imageUrl").getValue().toString()).placeholder(Integer.parseInt("https://www.wallpapers13.com/wp-content/uploads/2016/01/Cool-and-Beautiful-Nature-desktop-wallpaper-image-2560X1600.jpg")).into(image);
                        loadImage(image,ds.child("imageUrl").getValue().toString());
                        image.setScaleType(ImageView.ScaleType.FIT_CENTER);
                    }
                }
            }
            @Override
            public void onCancelled(@NonNull DatabaseError error) {
            }
        });


        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SaveFeedback();
            }
        });
    }

    private void SaveFeedback() {
        databaseReference = FirebaseDatabase.getInstance().getReference("Feedback");
        rate=rb.getRating();
        textFeedback = writtenFB.getText().toString();
        FeedbackData feedbackData = new FeedbackData(email,rate,recipeName,textFeedback);
        String FeedbackUploadId = databaseReference.push().getKey();
        databaseReference.child(FeedbackUploadId).setValue(feedbackData).addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {
                if(task.isSuccessful()) {
                    Toast.makeText(FeedbackPage.this, "Feedback Saved Successfully.", Toast.LENGTH_LONG).show();
                } else {
                    Toast.makeText(FeedbackPage.this, "Something went wrong. Try Again!!", Toast.LENGTH_LONG).show();
                }
            }
        });

    }

    public void loadImage (View view, String uri){
        class ImageLoadTask extends AsyncTask<Void, Void, Bitmap> {
            private String url;
            private ImageView imageView;

            public ImageLoadTask(String url, ImageView imageView) {
                this.url = url;
                this.imageView = imageView;
            }

            @Override
            protected Bitmap doInBackground(Void... params) {
                try {
                    URL Connection = new URL(url);
                    InputStream input = Connection.openStream();
                    myBitmap = BitmapFactory.decodeStream(input);
                    Bitmap resized = Bitmap.createScaledBitmap(myBitmap, 1000, 1000, true);
                    return resized;

                } catch (Exception e) {
                    e.printStackTrace();
                }
                return null;
            }

            protected void onPostExecute(Bitmap result) {
                super.onPostExecute(result);
                imageView.setImageBitmap(result);
            }
        }
        ImageLoadTask obj = new ImageLoadTask(uri, (ImageView) view);
        obj.execute();
    }

}