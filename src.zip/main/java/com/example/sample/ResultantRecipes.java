package com.example.sample;


import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;

import android.view.View;
import android.widget.AdapterView;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class ResultantRecipes extends AppCompatActivity {
    Switch recipeType;
    ListView recipeList;

    int flag = 0;

    DatabaseReference reference;
    FirebaseFirestore firebaseFirestore;
    CollectionReference collectionReference;

    ArrayList<String> listNames = new ArrayList<>();


    ArrayList<String> rImg = new ArrayList<>();
    RecipeData rd;
    ImageView imageView;
    TextView recipeText;

    ArrayList<String> checkList = new ArrayList<>();
    List<String> ingredientsList = new ArrayList<>();



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_resultant_recipes);
        recipeType = (Switch) findViewById(R.id.vns);
        recipeList = (ListView) findViewById(R.id.listViewRecipe);
        imageView = (ImageView) findViewById(R.id.r_img);
        recipeText = (TextView) findViewById(R.id.r_title);
        rd = new RecipeData();
        Bundle b = getIntent().getExtras();
        checkList = b.getStringArrayList("the list");
        Collections.sort(checkList);
        Toast.makeText(ResultantRecipes.this, "Select Recipe Type", Toast.LENGTH_SHORT).show();



        reference = FirebaseDatabase.getInstance().getReference("Recipes");
        firebaseFirestore = FirebaseFirestore.getInstance();
        collectionReference = firebaseFirestore.collection("main");


        CustomRecipe adapter = new CustomRecipe(ResultantRecipes.this,listNames,rImg);

        recipeType.setText("Veg");
        listNames.clear();
        rImg.clear();
        collectionReference.get().addOnSuccessListener(new OnSuccessListener<QuerySnapshot>() {
            @Override
            public void onSuccess(QuerySnapshot queryDocumentSnapshots) {
                for(QueryDocumentSnapshot documentSnapshot : queryDocumentSnapshots) {
                    RecipeData recipeData = documentSnapshot.toObject(RecipeData.class);
                    if ("veg".equals(recipeData.getType())) {

                        ingredientsList.clear();
                        for (String ing : recipeData.getIngs()) {
                            ingredientsList.add(ing);
                        }
                        Collections.sort(ingredientsList);

                        if (!(checkList.isEmpty()) && checkList != null) {
                            //Toast.makeText(ResultantRecipes.this, "checkList is not empty", Toast.LENGTH_SHORT).show();
                            flag = matchIngredients(ingredientsList);
                            //Toast.makeText(ResultantRecipes.this, "flag = " + flag, Toast.LENGTH_SHORT).show();

                        }
                        if (flag == 1) {
                            listNames.add(recipeData.getrName());
                            rImg.add(recipeData.getImageUrl());
                            //Toast.makeText(ResultantRecipes.this, recipeData.getrName(), Toast.LENGTH_SHORT).show();
                            adapter.notifyDataSetChanged();
                        }

                        if (checkList.isEmpty()) {
                            listNames.add(recipeData.getrName());
                            rImg.add(recipeData.getImageUrl());
                            adapter.notifyDataSetChanged();
                        }

                    }
                }
            }
        });
        recipeList.setAdapter(adapter);

        recipeType.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if(b) {

                    recipeType.setText("Veg");
                    listNames.clear();
                    rImg.clear();

                    collectionReference.get().addOnSuccessListener(new OnSuccessListener<QuerySnapshot>() {

                        @Override
                        public void onSuccess(QuerySnapshot queryDocumentSnapshots) {


                            for(QueryDocumentSnapshot documentSnapshot : queryDocumentSnapshots) {
                                RecipeData recipeData = documentSnapshot.toObject(RecipeData.class);
                                if ("veg".equals(recipeData.getType())) {

                                    ingredientsList.clear();
                                    for (String ing : recipeData.getIngs()) {
                                        ingredientsList.add(ing);
                                    }
                                    Collections.sort(ingredientsList);
                                    //Toast.makeText(ResultantRecipes.this, ingredientsList.toString(), Toast.LENGTH_SHORT).show();

                                    //Toast.makeText(ResultantRecipes.this, ingredientsList.get(2), Toast.LENGTH_SHORT).show();
                                    if (!(checkList.isEmpty()) && checkList != null) {
                                        //Toast.makeText(ResultantRecipes.this, "checkList is not empty", Toast.LENGTH_SHORT).show();
                                        flag = matchIngredients(ingredientsList);
                                        //Toast.makeText(ResultantRecipes.this, "flag = " + flag, Toast.LENGTH_SHORT).show();

                                    }
                                    if (flag == 1) {
                                        listNames.add(recipeData.getrName());
                                        rImg.add(recipeData.getImageUrl());
                                        //Toast.makeText(ResultantRecipes.this, recipeData.getrName(), Toast.LENGTH_SHORT).show();
                                        adapter.notifyDataSetChanged();
                                    }

                                    if (checkList.isEmpty()) {
                                        listNames.add(recipeData.getrName());
                                        rImg.add(recipeData.getImageUrl());
                                        adapter.notifyDataSetChanged();
                                    }

                                }
                            }
                        }
                    });



                } else {
                    recipeType.setText("Non-Veg");
                    listNames.clear();
                    rImg.clear();
                    collectionReference.get().addOnSuccessListener(new OnSuccessListener<QuerySnapshot>() {
                        @Override
                        public void onSuccess(QuerySnapshot queryDocumentSnapshots) {
                            for(QueryDocumentSnapshot documentSnapshot : queryDocumentSnapshots) {
                                RecipeData recipeData = documentSnapshot.toObject(RecipeData.class);
                                if ("non-veg".equals(recipeData.getType())) {

                                    ingredientsList.clear();
                                    for (String ing : recipeData.getIngs()) {
                                        ingredientsList.add(ing);
                                    }
                                    Collections.sort(ingredientsList);

                                    //Toast.makeText(ResultantRecipes.this, ingredientsList.get(2), Toast.LENGTH_SHORT).show();
                                    if (!(checkList.isEmpty()) && checkList != null) {
                                        //Toast.makeText(ResultantRecipes.this, "checkList is not empty", Toast.LENGTH_SHORT).show();
                                        flag = matchIngredients(ingredientsList);
                                        //Toast.makeText(ResultantRecipes.this, "flag = " + flag, Toast.LENGTH_SHORT).show();

                                    }
                                    if (flag == 1) {
                                        listNames.add(recipeData.getrName());
                                        rImg.add(recipeData.getImageUrl());
                                        //Toast.makeText(ResultantRecipes.this, recipeData.getrName(), Toast.LENGTH_SHORT).show();
                                        adapter.notifyDataSetChanged();
                                    }

                                    if (checkList.isEmpty()) {
                                        listNames.add(recipeData.getrName());
                                        rImg.add(recipeData.getImageUrl());
                                        adapter.notifyDataSetChanged();
                                    }

                                }
                            }
                        }
                    });
                }
                recipeList.setAdapter(adapter);
            }
        });




        recipeList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {

                Intent intent = new Intent(ResultantRecipes.this,RecipeDetails.class);
                intent.putExtra("name", listNames.get(i));
                startActivity(intent);

            }
        });
    }

    public int matchIngredients(List<String> list) {
        int flag1 = 1;
        for(String j: list) {
            //Toast.makeText(this, j, Toast.LENGTH_SHORT).show();
            if (checkPresenceIncheckList(j)) {
                flag1 = 1;
                //Toast.makeText(this, "flag1 = " + flag1, Toast.LENGTH_SHORT).show();
            } else {
                flag1 = 0;
                break;
            }
        }
        return flag1;

    }

    public boolean checkPresenceIncheckList(String ing) {
        for(String k: checkList) {
            //Toast.makeText(this, k, Toast.LENGTH_SHORT).show();
            if (ing.equals(k)) {
                //checkFlag = 1;
                return true;
            } else {
                //checkFlag = 0;
                continue;
            }
        }
        return false;

    }

    public void loadRecipes() {
        collectionReference.get().addOnSuccessListener(new OnSuccessListener<QuerySnapshot>() {
            @Override
            public void onSuccess(QuerySnapshot queryDocumentSnapshots) {

            }
        });
    }
}