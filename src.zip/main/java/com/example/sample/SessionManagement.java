package com.example.sample;

import android.content.SharedPreferences;
import android.content.Context;


public class SessionManagement {
    SharedPreferences sharedPreferences;
    SharedPreferences.Editor editor;
    String SHARED_PREF_NAME = "session";
    String SESSION_KEY = "session_user";

    public SessionManagement(Context context) {
        sharedPreferences = context.getSharedPreferences(SHARED_PREF_NAME, Context.MODE_PRIVATE);
        editor = sharedPreferences.edit();
    }


    public void saveSession(user user) {
        String id = user.getEmail();
        editor.putString(SESSION_KEY,id).commit();

    }

    public String getSession () {

        return sharedPreferences.getString(SESSION_KEY, "id");
    }

    public void removeSession() {
        editor.putString(SESSION_KEY,"id").commit();
    }
}
