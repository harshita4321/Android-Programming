package com.example.sample;

public class user {
    public String fullName, email, pass;
    public user() {
    }

    public user(String fullName, String email, String pass) {
        this.fullName = fullName;
        this.email = email;
        this.pass = pass;
    }

    public user(String email) {
        this.email = email;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPass() {
        return pass;
    }

    public void setPass(String pass) {
        this.pass = pass;
    }
}
