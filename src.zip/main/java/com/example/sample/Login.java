package com.example.sample;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.FirebaseDatabase;

public class Login extends AppCompatActivity implements View.OnClickListener{
    private FirebaseAuth mAuth;

    TextView forgotPass;
    EditText email, pass;
    Button login, register;
    ProgressBar bar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        forgotPass = (TextView) findViewById(R.id.forgetpass);
        email = (EditText) findViewById(R.id.lemail);
        pass = (EditText) findViewById(R.id.lpass);
        login = (Button) findViewById(R.id.login);
        register = (Button) findViewById(R.id.register);
        bar = (ProgressBar) findViewById(R.id.lbar);
        login.setOnClickListener(this::onClick);
        register.setOnClickListener(this::onClick);
        mAuth = FirebaseAuth.getInstance();
        forgotPass.setOnClickListener(this::onClick);
    }

    @Override
    protected void onStart() {
        super.onStart();

        checkSession();

    }

    private void checkSession() {
        SessionManagement sessionManagement = new SessionManagement(Login.this);
        String id = sessionManagement.getSession();

        if(!(id.equals("id"))) {
            MoveToDashboard();
        }
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.register:
                startActivity(new Intent(this,Registration.class));
                break;
            case R.id.login:
                loginUser();
                break;
            case R.id.forgetpass:
                startActivity(new Intent(this, ForgotPassword.class));
                break;
        }
    }

    private void loginUser() {
        String Email = email.getText().toString().trim();
        String Pass = pass.getText().toString().trim();

        if(Email.isEmpty()) {
            email.setError("Email is required.");
            email.requestFocus();
            return;
        }
        if(!Patterns.EMAIL_ADDRESS.matcher(Email).matches()) {
            email.setError("Please enter a valid email.");
            email.requestFocus();
            return;
        }
        if(Pass.isEmpty()) {
            pass.setError("Password is required.");
            pass.requestFocus();
            return;
        }
        if(Pass.length() < 6 || Pass.length() > 15) {
            pass.setError("Password length should be 6-15 characters.");
            pass.requestFocus();
            return;
        }

        bar.setVisibility(View.VISIBLE);

        mAuth.signInWithEmailAndPassword(Email, Pass).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if(task.isSuccessful()) {
                    FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
                    if(user.isEmailVerified()) {
                        user us = new user(Email);
                        SessionManagement sessionManagement = new SessionManagement(Login.this);
                        sessionManagement.saveSession(us);
                        Toast.makeText(Login.this, "Login Successful", Toast.LENGTH_LONG).show();
                        bar.setVisibility(View.GONE);
                        MoveToDashboard();

                    } else {
                        user.sendEmailVerification();
                        Toast.makeText(Login.this, "Check your email to verify your account.", Toast.LENGTH_LONG).show();
                        bar.setVisibility(View.GONE);
                    }
                    
                } else {
                    Toast.makeText(Login.this, "Login Failed!! Please Try Again!", Toast.LENGTH_LONG).show();
                    bar.setVisibility(View.GONE);
                }
            }
        });

    }

    private void MoveToDashboard() {
        startActivity(new Intent(Login.this,ThisDashBoard.class));
    }
}