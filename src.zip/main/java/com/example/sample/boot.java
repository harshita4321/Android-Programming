package com.example.sample;

import android.content.Intent;
import android.os.Bundle;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class boot extends AppCompatActivity {

    Animation fadeAnim, bottomAnim, topAnim;
    ImageView image;
    TextView logo_name;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_boot);

        fadeAnim = AnimationUtils.loadAnimation(this, R.anim.fade_animation);
        bottomAnim = AnimationUtils.loadAnimation(this, R.anim.bottom_animation);
        topAnim = AnimationUtils.loadAnimation(this, R.anim.top_animation);

        image = findViewById(R.id.logo);
        logo_name = findViewById(R.id.textView);

        image.setAnimation(topAnim);
        logo_name.setAnimation(fadeAnim);

        Thread welcomeThread = new Thread() {
            public void run(){
                try {
                    super.run();
                    sleep(3000); //Delay 3 sec
                } catch (Exception e){

                }finally {

                    startActivity(new Intent(boot.this,Login.class));
                    finish();

                }
            }

        };
        welcomeThread.start();



    }

}