package com.example.sample;

public class FeedbackData {
    String email;
    float rating;
    String recipeName;
    String textFeedback;

    public FeedbackData() {
    }

    public FeedbackData(String email, float rating, String recipeName, String textFeedback) {
        this.email = email;
        this.rating = rating;
        this.recipeName = recipeName;
        this.textFeedback = textFeedback;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public float getRating() {
        return rating;
    }

    public void setRating(float rating) {
        this.rating = rating;
    }

    public String getRecipeName() {
        return recipeName;
    }

    public void setRecipeName(String recipeName) {
        this.recipeName = recipeName;
    }

    public String getTextFeedback() {
        return textFeedback;
    }

    public void setTextFeedback(String textFeedback) {
        this.textFeedback = textFeedback;
    }

}
